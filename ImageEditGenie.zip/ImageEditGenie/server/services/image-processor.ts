import OpenAI from "openai";
import { storage } from "../storage";
import sharp from "sharp";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

export interface ProcessingOptions {
  quality: "high" | "standard" | "fast";
  edgeRefinement: number;
  feathering: number;
  brightness?: number;
  contrast?: number;
  saturation?: number;
}

export interface MixingOptions {
  blendMode: "natural" | "artistic" | "dramatic";
  layers: Array<{
    opacity: number;
    scale: number;
    x: number;
    y: number;
  }>;
}

export class ImageProcessor {
  
  async removeBackground(
    imageBase64: string, 
    options: ProcessingOptions,
    jobId: string
  ): Promise<string> {
    try {
      await storage.updateJobStatus(jobId, "processing", 10);

      // Use OpenAI Vision to analyze the image first
      const analysisResponse = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Analyze this image and identify the main subject that should be preserved when removing the background. Describe the subject's edges and complexity for optimal background removal processing."
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${imageBase64}`
                }
              }
            ],
          },
        ],
        max_tokens: 300,
      });

      await storage.updateJobStatus(jobId, "processing", 30);

      // Check if Remove.bg API key is available
      const removeApiKey = process.env.REMOVEBG_API_KEY || process.env.REMOVE_BG_API_KEY || "";
      
      let resultBase64: string;
      
      if (removeApiKey) {
        console.log("Using Remove.bg API for background removal...");
        
        await storage.updateJobStatus(jobId, "processing", 50);

        // Use Remove.bg API for professional background removal
        const response = await fetch("https://api.remove.bg/v1.0/removebg", {
          method: "POST",
          headers: {
            "X-Api-Key": removeApiKey,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            image_file_b64: imageBase64,
            size: options.quality === "high" ? "4k" : options.quality === "standard" ? "regular" : "preview",
            format: "png"
          })
        });

        if (!response.ok) {
          throw new Error(`Remove.bg API failed: ${response.statusText}`);
        }

        const resultBuffer = await response.arrayBuffer();
        resultBase64 = Buffer.from(resultBuffer).toString('base64');
        
      } else {
        console.log("Remove.bg API key not found, using OpenAI for background generation...");
        
        await storage.updateJobStatus(jobId, "processing", 50);

        // Fallback: Use OpenAI to generate a version with transparent background
        // This creates a new image based on the subject description
        const generationResponse = await openai.images.generate({
          prompt: `Create a PNG image with transparent background featuring only the main subject from this image description: ${analysisResponse.choices[0]?.message?.content || "main subject"}. Remove all background elements completely, isolate the subject with clean edges.`,
          n: 1,
          size: options.quality === "high" ? "1024x1024" : "512x512",
          response_format: "b64_json",
          quality: "hd"
        });

        if (!generationResponse.data || !generationResponse.data[0]?.b64_json) {
          throw new Error("OpenAI image generation failed - no image returned");
        }

        resultBase64 = generationResponse.data[0].b64_json;
      }

      await storage.updateJobStatus(jobId, "processing", 80);

      await storage.updateJobStatus(jobId, "processing", 90);

      // Apply additional adjustments if specified
      let finalImage = resultBase64;
      if (options.brightness !== 0 || options.contrast !== 0 || options.saturation !== 0) {
        finalImage = await this.applyAdjustments(resultBase64, options);
      }

      await storage.updateJobStatus(jobId, "completed", 100);
      return finalImage;

    } catch (error) {
      await storage.updateJobStatus(jobId, "failed", 0, error instanceof Error ? error.message : "Unknown error");
      throw error;
    }
  }

  async mixImages(
    images: string[], 
    options: MixingOptions,
    jobId: string
  ): Promise<string> {
    try {
      await storage.updateJobStatus(jobId, "processing", 10);

      if (images.length < 2) {
        throw new Error("At least 2 images are required for mixing");
      }

      console.log(`Starting image mixing with ${images.length} images using ${options.blendMode} blend mode`);

      // Convert base64 images to buffers
      const imageBuffers = images.map(img => {
        const base64Data = img.includes(',') ? img.split(',')[1] : img;
        return Buffer.from(base64Data, 'base64');
      });

      await storage.updateJobStatus(jobId, "processing", 30);

      // Get metadata for the first image to determine canvas size
      const baseImage = sharp(imageBuffers[0]);
      const { width: canvasWidth, height: canvasHeight } = await baseImage.metadata();
      
      if (!canvasWidth || !canvasHeight) {
        throw new Error("Could not determine base image dimensions");
      }

      console.log(`Canvas size: ${canvasWidth}x${canvasHeight}`);

      // Start with the base image
      let composite = baseImage.clone();

      await storage.updateJobStatus(jobId, "processing", 50);

      // Apply each overlay layer according to options
      for (let i = 1; i < imageBuffers.length; i++) {
        // Use i-1 for layer options since layers[0] corresponds to overlay 1 (image index 1)
        const layerIndex = i - 1;
        const layerOptions = options.layers[layerIndex] || { opacity: 75, scale: 100, x: 0, y: 0 };
        
        console.log(`Processing layer ${i}: opacity=${layerOptions.opacity}%, scale=${layerOptions.scale}%, x=${layerOptions.x}, y=${layerOptions.y}`);

        // Process the overlay image
        let overlayImage = sharp(imageBuffers[i]);
        
        // Apply scaling if needed
        if (layerOptions.scale !== 100) {
          const overlayMeta = await overlayImage.metadata();
          const newWidth = Math.round((overlayMeta.width || canvasWidth) * layerOptions.scale / 100);
          const newHeight = Math.round((overlayMeta.height || canvasHeight) * layerOptions.scale / 100);
          overlayImage = overlayImage.resize(newWidth, newHeight);
        }

        // Determine Sharp blend mode based on options
        let blendMode: sharp.Blend = 'over'; // default
        switch (options.blendMode) {
          case 'natural':
            blendMode = 'over';
            break;
          case 'artistic':
            blendMode = 'multiply';
            break;
          case 'dramatic':
            blendMode = 'overlay';
            break;
        }

        // Get overlay buffer
        const overlayBuffer = await overlayImage.png().toBuffer();
        
        // Create composite options with proper opacity
        const compositeOpts: any = {
          input: overlayBuffer,
          top: Math.round(layerOptions.y),
          left: Math.round(layerOptions.x),
          blend: blendMode
        };

        // Apply opacity if less than 100% (Sharp supports this in newer versions)
        if (layerOptions.opacity < 100) {
          compositeOpts.opacity = layerOptions.opacity / 100;
        }
        
        composite = composite.composite([compositeOpts]);
      }

      await storage.updateJobStatus(jobId, "processing", 80);

      // Finalize the composite image
      const finalBuffer = await composite.png().toBuffer();
      const resultBase64 = finalBuffer.toString('base64');

      await storage.updateJobStatus(jobId, "processing", 90);

      console.log("Image mixing completed successfully");
      await storage.updateJobStatus(jobId, "completed", 100);
      
      // Return as data URL for consistency with the frontend
      return resultBase64;

    } catch (error) {
      console.error("Image mixing failed:", error);
      await storage.updateJobStatus(jobId, "failed", 0, error instanceof Error ? error.message : "Unknown error");
      throw error;
    }
  }

  private async applyAdjustments(imageBase64: string, options: ProcessingOptions): Promise<string> {
    // In a real implementation, this would use Sharp or similar library
    // For now, return the original image
    return imageBase64;
  }
}

export const imageProcessor = new ImageProcessor();
