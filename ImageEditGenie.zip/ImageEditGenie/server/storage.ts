import { type User, type InsertUser, type Project, type InsertProject, type ImageProcessingJob, type InsertJob } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createProject(project: InsertProject): Promise<Project>;
  getProject(id: string): Promise<Project | undefined>;
  getUserProjects(userId: string): Promise<Project[]>;
  updateProject(id: string, updates: Partial<Project>): Promise<Project | undefined>;
  
  createJob(job: InsertJob): Promise<ImageProcessingJob>;
  getJob(id: string): Promise<ImageProcessingJob | undefined>;
  updateJobStatus(id: string, status: string, progress?: number, errorMessage?: string): Promise<void>;
  getProjectJobs(projectId: string): Promise<ImageProcessingJob[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private projects: Map<string, Project>;
  private jobs: Map<string, ImageProcessingJob>;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.jobs = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = { 
      userId: insertProject.userId || null,
      name: insertProject.name,
      type: insertProject.type,
      originalImageUrl: insertProject.originalImageUrl || null,
      processedImageUrl: insertProject.processedImageUrl || null,
      settings: insertProject.settings || null,
      id, 
      createdAt: new Date() 
    };
    this.projects.set(id, project);
    return project;
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    return Array.from(this.projects.values())
      .filter(project => project.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project | undefined> {
    const existing = this.projects.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.projects.set(id, updated);
    return updated;
  }

  async createJob(insertJob: InsertJob): Promise<ImageProcessingJob> {
    const id = randomUUID();
    const job: ImageProcessingJob = {
      projectId: insertJob.projectId || null,
      status: insertJob.status || "pending",
      progress: insertJob.progress || null,
      errorMessage: insertJob.errorMessage || null,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.jobs.set(id, job);
    return job;
  }

  async getJob(id: string): Promise<ImageProcessingJob | undefined> {
    return this.jobs.get(id);
  }

  async updateJobStatus(id: string, status: string, progress?: number, errorMessage?: string): Promise<void> {
    const job = this.jobs.get(id);
    if (!job) return;

    job.status = status;
    if (progress !== undefined) job.progress = progress;
    if (errorMessage !== undefined) job.errorMessage = errorMessage;
    if (status === "completed" || status === "failed") {
      job.completedAt = new Date();
    }

    this.jobs.set(id, job);
  }

  async getProjectJobs(projectId: string): Promise<ImageProcessingJob[]> {
    return Array.from(this.jobs.values())
      .filter(job => job.projectId === projectId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }
}

export const storage = new MemStorage();
