interface ControlsPanelProps {
  options: any;
  onOptionsChange: (options: any) => void;
  onProcess: () => void;
  isProcessing: boolean;
  canProcess: boolean;
  processButtonText: string;
  processIcon: string;
}

export default function ControlsPanel({
  options,
  onOptionsChange,
  onProcess,
  isProcessing,
  canProcess,
  processButtonText,
  processIcon,
}: ControlsPanelProps) {
  const updateOption = (key: string, value: any) => {
    onOptionsChange({ ...options, [key]: value });
  };

  return (
    <div className="space-y-6">
      {/* Processing Options */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Processing Options</h3>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Quality</label>
            <select 
              className="w-full px-3 py-2 bg-background border border-input rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              value={options.quality}
              onChange={(e) => updateOption("quality", e.target.value)}
              data-testid="quality-select"
            >
              <option value="high">High Quality (4K)</option>
              <option value="standard">Standard (1080p)</option>
              <option value="fast">Fast (720p)</option>
            </select>
          </div>
          
          {options.edgeRefinement !== undefined && (
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Edge Refinement</label>
              <div className="flex items-center space-x-3">
                <input 
                  type="range" 
                  className="flex-1 h-2 bg-muted rounded-lg appearance-none cursor-pointer" 
                  min="0" 
                  max="100" 
                  value={options.edgeRefinement}
                  onChange={(e) => updateOption("edgeRefinement", parseInt(e.target.value))}
                  data-testid="edge-refinement-slider"
                />
                <span className="text-sm text-muted-foreground w-8">{options.edgeRefinement}%</span>
              </div>
            </div>
          )}

          {options.feathering !== undefined && (
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Feathering</label>
              <div className="flex items-center space-x-3">
                <input 
                  type="range" 
                  className="flex-1 h-2 bg-muted rounded-lg appearance-none cursor-pointer" 
                  min="0" 
                  max="100" 
                  value={options.feathering}
                  onChange={(e) => updateOption("feathering", parseInt(e.target.value))}
                  data-testid="feathering-slider"
                />
                <span className="text-sm text-muted-foreground w-8">{options.feathering}%</span>
              </div>
            </div>
          )}
        </div>
        
        <button 
          className="w-full mt-6 px-4 py-2 bg-primary text-primary-foreground font-medium rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
          onClick={onProcess}
          disabled={!canProcess}
          data-testid="process-button"
        >
          <i className={`${processIcon} mr-2`}></i>
          {isProcessing ? "Processing..." : processButtonText}
        </button>
      </div>

      {/* Image Adjustments */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Adjustments</h3>
        <div className="space-y-4">
          {["brightness", "contrast", "saturation"].map((adjustment) => (
            <div key={adjustment}>
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium text-foreground capitalize">
                  {adjustment}
                </label>
                <span className="text-sm text-muted-foreground">
                  {options[adjustment] || 0}
                </span>
              </div>
              <input 
                type="range" 
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer" 
                min="-100" 
                max="100" 
                value={options[adjustment] || 0}
                onChange={(e) => updateOption(adjustment, parseInt(e.target.value))}
                data-testid={`${adjustment}-slider`}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Export Options */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Export</h3>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Format</label>
            <div className="grid grid-cols-2 gap-2">
              <button className="px-3 py-2 text-sm font-medium bg-primary text-primary-foreground rounded-md">
                PNG
              </button>
              <button className="px-3 py-2 text-sm font-medium bg-secondary text-secondary-foreground rounded-md">
                JPG
              </button>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Resolution</label>
            <select className="w-full px-3 py-2 bg-background border border-input rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring">
              <option>Original (4K)</option>
              <option>2K (2048×2048)</option>
              <option>1080p (1920×1080)</option>
              <option>720p (1280×720)</option>
            </select>
          </div>

          <button 
            className="w-full px-4 py-2 bg-accent text-accent-foreground font-medium rounded-md hover:bg-accent/80 transition-colors"
            data-testid="download-button"
          >
            <i className="fas fa-download mr-2"></i>
            Download Image
          </button>
        </div>
      </div>
    </div>
  );
}
