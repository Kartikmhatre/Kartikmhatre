# ImageCraft AI - Image Processing Application

## Overview

ImageCraft AI is a modern web application that provides two main AI-powered image processing features: background removal and image mixing. The application enables users to upload images and apply intelligent processing to achieve high-quality results up to 4K resolution. Built with a React frontend and Express.js backend, the application uses OpenAI's GPT-5 model for advanced image analysis and processing capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client application is built with React 18 and TypeScript, using Vite as the build tool for fast development and optimized production builds. The UI is constructed with the shadcn/ui component library built on top of Radix UI primitives, providing a modern and accessible design system. TailwindCSS handles styling with a comprehensive design token system including dark mode support.

**State Management**: TanStack Query (React Query) manages server state and API interactions, providing caching, background updates, and optimistic updates. Local component state is handled with React hooks.

**Routing**: Wouter provides lightweight client-side routing for navigation between different views and tools.

**Component Structure**: The application follows a modular component architecture with separate components for each major feature (BackgroundRemoval, ImageMixing), shared UI components, and utility functions.

### Backend Architecture
The server is built with Express.js and TypeScript, following a RESTful API design pattern. The architecture uses a clean separation of concerns with dedicated layers for routing, business logic, and data access.

**API Layer**: Express routes handle HTTP requests and responses, with middleware for logging, error handling, and request parsing.

**Service Layer**: Dedicated services handle image processing logic, integrating with OpenAI's API for intelligent image analysis and manipulation.

**Storage Layer**: An abstract storage interface allows for flexible data persistence implementations, currently using in-memory storage for development with the ability to easily switch to database persistence.

### Data Storage Solutions
The application uses Drizzle ORM with PostgreSQL for production data persistence. The database schema includes tables for users, projects, and image processing jobs, allowing for comprehensive project management and processing history tracking.

**Development Storage**: In-memory storage implementation for rapid development and testing.

**Production Database**: PostgreSQL with connection pooling via Neon Database serverless driver for scalable production deployment.

**File Storage**: Images are handled through base64 encoding for processing, with the architecture supporting future integration of cloud storage solutions like AWS S3 or Cloudinary.

### Authentication and Authorization
The application uses a session-based authentication system with connect-pg-simple for session storage in PostgreSQL. User authentication is handled through username/password credentials with secure session management.

**Session Management**: Express sessions with PostgreSQL storage for persistence across server restarts.

**Authorization**: Route-level protection ensures users can only access their own projects and processing jobs.

### External Service Integrations

**OpenAI Integration**: The application integrates with OpenAI's GPT-5 model for advanced image analysis and processing instructions. The AI service analyzes uploaded images to optimize background removal and image mixing parameters.

**Image Processing Pipeline**: Multi-stage processing workflow that includes image validation, AI-powered analysis, parameter optimization, and final processing with progress tracking.

**File Upload Handling**: Multer middleware handles multipart file uploads with size limits and type validation, converting images to base64 for processing workflows.

The architecture prioritizes modularity, type safety, and scalability while maintaining development simplicity through clear abstractions and modern tooling.