export interface ProcessedImage {
  url: string;
  width: number;
  height: number;
  size: number;
}

export interface ProcessingOptions {
  quality: "high" | "standard" | "fast";
  format: "png" | "jpg" | "webp";
  brightness?: number;
  contrast?: number;
  saturation?: number;
}

export class ImageProcessingClient {
  
  static async validateImage(file: File): Promise<boolean> {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        // Check dimensions and file size
        const isValidSize = img.width <= 4096 && img.height <= 4096;
        const isValidFileSize = file.size <= 10 * 1024 * 1024; // 10MB
        resolve(isValidSize && isValidFileSize);
      };
      img.onerror = () => resolve(false);
      img.src = URL.createObjectURL(file);
    });
  }

  static async resizeImage(file: File, maxWidth: number, maxHeight: number): Promise<File> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();

      img.onload = () => {
        const { width, height } = img;
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        
        canvas.width = width * ratio;
        canvas.height = height * ratio;
        
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const resizedFile = new File([blob], file.name, { type: file.type });
            resolve(resizedFile);
          }
        }, file.type, 0.9);
      };

      img.src = URL.createObjectURL(file);
    });
  }

  static async convertToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        // Remove data URL prefix to get just the base64 part
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  static async applyFilters(imageUrl: string, options: ProcessingOptions): Promise<string> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();

      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        
        // Apply brightness, contrast, saturation filters
        let filterString = '';
        if (options.brightness !== undefined && options.brightness !== 0) {
          filterString += `brightness(${100 + options.brightness}%) `;
        }
        if (options.contrast !== undefined && options.contrast !== 0) {
          filterString += `contrast(${100 + options.contrast}%) `;
        }
        if (options.saturation !== undefined && options.saturation !== 0) {
          filterString += `saturate(${100 + options.saturation}%) `;
        }

        ctx.filter = filterString.trim();
        ctx.drawImage(img, 0, 0);
        
        const quality = options.quality === "high" ? 0.95 : options.quality === "standard" ? 0.85 : 0.75;
        const dataUrl = canvas.toDataURL(`image/${options.format}`, quality);
        resolve(dataUrl);
      };

      img.crossOrigin = "anonymous";
      img.src = imageUrl;
    });
  }

  static getImageDimensions(file: File): Promise<{ width: number; height: number }> {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        resolve({ width: img.width, height: img.height });
      };
      img.src = URL.createObjectURL(file);
    });
  }
}
