import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import FileUpload from "./file-upload";
import ImagePreview from "./image-preview";
import ControlsPanel from "./controls-panel";
import ExportModal from "./export-modal";

interface ProcessingOptions {
  quality: "high" | "standard" | "fast";
  edgeRefinement: number;
  feathering: number;
  brightness: number;
  contrast: number;
  saturation: number;
}

export default function BackgroundRemoval() {
  const [currentProject, setCurrentProject] = useState<string | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [showExportModal, setShowExportModal] = useState(false);
  const [processingOptions, setProcessingOptions] = useState<ProcessingOptions>({
    quality: "standard",
    edgeRefinement: 75,
    feathering: 25,
    brightness: 0,
    contrast: 0,
    saturation: 0,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createProjectMutation = useMutation({
    mutationFn: async (data: { name: string; type: string }) => {
      const response = await apiRequest("POST", "/api/projects", data);
      return response.json();
    },
    onSuccess: (project) => {
      setCurrentProject(project.id);
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async ({ file, projectId }: { file: File; projectId: string }) => {
      const formData = new FormData();
      formData.append('image', file);
      
      const response = await fetch(`/api/projects/${projectId}/upload`, {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setUploadedImage(data.imageUrl);
      toast({
        title: "Image uploaded successfully",
        description: "You can now process the image to remove the background.",
      });
    },
    onError: () => {
      toast({
        title: "Upload failed",
        description: "Please try uploading your image again.",
        variant: "destructive",
      });
    },
  });

  const processBackgroundMutation = useMutation({
    mutationFn: async ({ projectId, options }: { projectId: string; options: ProcessingOptions }) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/remove-background`, options);
      return response.json();
    },
    onSuccess: async (data) => {
      const jobId = data.jobId;
      setIsProcessing(true);
      setProcessingProgress(0);

      // Poll for job status
      const pollInterval = setInterval(async () => {
        try {
          const jobResponse = await fetch(`/api/jobs/${jobId}`);
          const job = await jobResponse.json();
          
          setProcessingProgress(job.progress || 0);
          
          if (job.status === "completed") {
            clearInterval(pollInterval);
            setIsProcessing(false);
            
            // Fetch updated project to get processed image
            const projectResponse = await fetch(`/api/projects/${currentProject}`);
            const project = await projectResponse.json();
            setProcessedImage(project.processedImageUrl);
            
            toast({
              title: "Background removed successfully",
              description: "Your image is ready for download.",
            });
          } else if (job.status === "failed") {
            clearInterval(pollInterval);
            setIsProcessing(false);
            toast({
              title: "Processing failed",
              description: job.errorMessage || "An error occurred during processing.",
              variant: "destructive",
            });
          }
        } catch (error) {
          clearInterval(pollInterval);
          setIsProcessing(false);
          toast({
            title: "Processing error",
            description: "Failed to check processing status.",
            variant: "destructive",
          });
        }
      }, 1000);
    },
    onError: () => {
      toast({
        title: "Processing failed",
        description: "Failed to start background removal.",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = async (file: File) => {
    if (!currentProject) {
      // Create new project first
      const projectName = `Background Removal - ${new Date().toLocaleDateString()}`;
      await createProjectMutation.mutateAsync({
        name: projectName,
        type: "background-removal",
      });
    }

    if (currentProject) {
      uploadMutation.mutate({ file, projectId: currentProject });
    }
  };

  const handleProcessBackground = () => {
    if (!currentProject || !uploadedImage) {
      toast({
        title: "No image to process",
        description: "Please upload an image first.",
        variant: "destructive",
      });
      return;
    }

    processBackgroundMutation.mutate({
      projectId: currentProject,
      options: processingOptions,
    });
  };

  return (
    <>
      {/* Header Bar */}
      <div className="h-14 bg-card border-b border-border flex items-center justify-between px-6" data-testid="header-bar">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold text-foreground">Background Removal</h2>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>•</span>
            <span>AI-Powered Processing</span>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            className="flex items-center space-x-2 px-3 py-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            data-testid="history-button"
          >
            <i className="fas fa-history w-4 h-4"></i>
            <span>History</span>
          </button>
          <button 
            className="flex items-center space-x-2 px-4 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
            onClick={() => setShowExportModal(true)}
            disabled={!processedImage}
            data-testid="export-button"
          >
            <i className="fas fa-download w-4 h-4"></i>
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 h-full">
          {/* Upload Area */}
          <div className="xl:col-span-2 space-y-6">
            <FileUpload
              onFileUpload={handleFileUpload}
              isUploading={uploadMutation.isPending}
              accept="image/*"
              maxSize={10 * 1024 * 1024} // 10MB
            />

            <ImagePreview
              originalImage={uploadedImage}
              processedImage={processedImage}
              isProcessing={isProcessing}
              progress={processingProgress}
            />
          </div>

          {/* Controls Panel */}
          <ControlsPanel
            options={processingOptions}
            onOptionsChange={setProcessingOptions}
            onProcess={handleProcessBackground}
            isProcessing={isProcessing}
            canProcess={!!uploadedImage && !isProcessing}
            processButtonText="Remove Background"
            processIcon="fas fa-cut"
          />
        </div>
      </div>

      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        imageUrl={processedImage}
        defaultFilename="background-removed"
      />
    </>
  );
}
