import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useToast } from "@/hooks/use-toast";

interface FileUploadProps {
  onFileUpload: (file: File) => void;
  isUploading: boolean;
  accept?: string;
  maxSize?: number;
  className?: string;
  label?: string;
  compact?: boolean;
}

export default function FileUpload({
  onFileUpload,
  isUploading,
  accept = "image/*",
  maxSize = 10 * 1024 * 1024, // 10MB
  className = "",
  label,
  compact = false,
}: FileUploadProps) {
  const { toast } = useToast();

  const onDrop = useCallback(
    (acceptedFiles: File[], rejectedFiles: any[]) => {
      if (rejectedFiles.length > 0) {
        const rejection = rejectedFiles[0];
        if (rejection.errors.some((e: any) => e.code === "file-too-large")) {
          toast({
            title: "File too large",
            description: `File size must be less than ${maxSize / (1024 * 1024)}MB`,
            variant: "destructive",
          });
        } else if (rejection.errors.some((e: any) => e.code === "file-invalid-type")) {
          toast({
            title: "Invalid file type",
            description: "Please upload a valid image file (JPG, PNG, WebP)",
            variant: "destructive",
          });
        }
        return;
      }

      if (acceptedFiles.length > 0) {
        onFileUpload(acceptedFiles[0]);
      }
    },
    [onFileUpload, maxSize, toast]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/*": [".jpg", ".jpeg", ".png", ".webp"],
    },
    maxSize,
    multiple: false,
    disabled: isUploading,
  });

  if (compact) {
    return (
      <div
        {...getRootProps()}
        className={`drop-zone rounded-lg p-4 text-center cursor-pointer ${
          isDragActive ? "drag-over" : ""
        } ${className}`}
        data-testid="file-upload-compact"
      >
        <input {...getInputProps()} />
        <div className="space-y-3">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center mx-auto">
            <i className="fas fa-image text-muted-foreground"></i>
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">{label || "Upload"}</p>
          </div>
          <button
            type="button"
            className="px-3 py-1.5 bg-secondary text-secondary-foreground text-xs font-medium rounded-md hover:bg-secondary/80 transition-colors"
            disabled={isUploading}
          >
            {isUploading ? "Uploading..." : "Browse"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4">Upload Image</h3>
      <div
        {...getRootProps()}
        className={`drop-zone rounded-lg p-8 text-center cursor-pointer ${
          isDragActive ? "drag-over" : ""
        } ${className}`}
        data-testid="file-upload"
      >
        <input {...getInputProps()} />
        <div className="space-y-4">
          <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto">
            {isUploading ? (
              <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <i className="fas fa-cloud-upload-alt text-muted-foreground text-xl"></i>
            )}
          </div>
          <div>
            <h4 className="text-base font-medium text-foreground mb-2">
              {isDragActive ? "Drop your image here" : "Drag & drop your image here"}
            </h4>
            <p className="text-sm text-muted-foreground mb-4">or click to browse files</p>
            <button
              type="button"
              className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
              disabled={isUploading}
              data-testid="browse-files-button"
            >
              {isUploading ? "Uploading..." : "Browse Files"}
            </button>
          </div>
          <div className="text-xs text-muted-foreground">
            Supports: JPG, PNG, WebP • Max size: {maxSize / (1024 * 1024)}MB • Up to 4K resolution
          </div>
        </div>
      </div>
    </div>
  );
}
