import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import FileUpload from "./file-upload";
import ImagePreview from "./image-preview";
import ExportModal from "./export-modal";

interface MixingOptions {
  blendMode: "natural" | "artistic" | "dramatic";
  layers: Array<{
    opacity: number;
    scale: number;
    x: number;
    y: number;
  }>;
}

export default function ImageMixing() {
  const [currentProject, setCurrentProject] = useState<string | null>(null);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [mixedImage, setMixedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [showExportModal, setShowExportModal] = useState(false);
  const [mixingOptions, setMixingOptions] = useState<MixingOptions>({
    blendMode: "natural",
    layers: [
      { opacity: 100, scale: 100, x: 0, y: 0 },
      { opacity: 75, scale: 100, x: 0, y: 0 },
      { opacity: 50, scale: 100, x: 0, y: 0 },
    ],
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createProjectMutation = useMutation({
    mutationFn: async (data: { name: string; type: string }) => {
      const response = await apiRequest("POST", "/api/projects", data);
      return response.json();
    },
    onSuccess: (project) => {
      setCurrentProject(project.id);
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
  });

  const mixImagesMutation = useMutation({
    mutationFn: async ({ projectId, images, options }: { 
      projectId: string; 
      images: string[]; 
      options: MixingOptions 
    }) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/mix-images`, {
        images,
        options,
      });
      return response.json();
    },
    onSuccess: async (data) => {
      const jobId = data.jobId;
      setIsProcessing(true);
      setProcessingProgress(0);

      // Poll for job status
      const pollInterval = setInterval(async () => {
        try {
          const jobResponse = await fetch(`/api/jobs/${jobId}`);
          const job = await jobResponse.json();
          
          setProcessingProgress(job.progress || 0);
          
          if (job.status === "completed") {
            clearInterval(pollInterval);
            setIsProcessing(false);
            
            // Fetch updated project to get mixed image
            const projectResponse = await fetch(`/api/projects/${currentProject}`);
            const project = await projectResponse.json();
            setMixedImage(project.processedImageUrl);
            
            toast({
              title: "Images mixed successfully",
              description: "Your composite image is ready for download.",
            });
          } else if (job.status === "failed") {
            clearInterval(pollInterval);
            setIsProcessing(false);
            toast({
              title: "Mixing failed",
              description: job.errorMessage || "An error occurred during mixing.",
              variant: "destructive",
            });
          }
        } catch (error) {
          clearInterval(pollInterval);
          setIsProcessing(false);
          toast({
            title: "Processing error",
            description: "Failed to check processing status.",
            variant: "destructive",
          });
        }
      }, 1000);
    },
    onError: () => {
      toast({
        title: "Mixing failed",
        description: "Failed to start image mixing.",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = async (file: File) => {
    if (uploadedImages.length >= 3) {
      toast({
        title: "Maximum images reached",
        description: "You can mix up to 3 images at once.",
        variant: "destructive",
      });
      return;
    }

    // Convert file to base64
    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setUploadedImages(prev => [...prev, imageUrl]);
    };
    reader.readAsDataURL(file);

    if (!currentProject) {
      const projectName = `Image Mixing - ${new Date().toLocaleDateString()}`;
      await createProjectMutation.mutateAsync({
        name: projectName,
        type: "image-mixing",
      });
    }

    toast({
      title: "Image added",
      description: `${uploadedImages.length + 1} of 3 images uploaded.`,
    });
  };

  const handleMixImages = () => {
    if (uploadedImages.length < 2) {
      toast({
        title: "Not enough images",
        description: "Please upload at least 2 images to mix.",
        variant: "destructive",
      });
      return;
    }

    if (!currentProject) {
      toast({
        title: "No project selected",
        description: "Please create a project first.",
        variant: "destructive",
      });
      return;
    }

    mixImagesMutation.mutate({
      projectId: currentProject,
      images: uploadedImages,
      options: mixingOptions,
    });
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const updateLayerOption = (index: number, key: keyof MixingOptions["layers"][0], value: number) => {
    setMixingOptions(prev => ({
      ...prev,
      layers: prev.layers.map((layer, i) => 
        i === index ? { ...layer, [key]: value } : layer
      ),
    }));
  };

  return (
    <>
      {/* Header Bar */}
      <div className="h-14 bg-card border-b border-border flex items-center justify-between px-6" data-testid="header-bar">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold text-foreground">Image Mixing</h2>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>•</span>
            <span>AI-Powered Blending</span>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            className="flex items-center space-x-2 px-3 py-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            data-testid="history-button"
          >
            <i className="fas fa-history w-4 h-4"></i>
            <span>History</span>
          </button>
          <button 
            className="flex items-center space-x-2 px-4 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
            onClick={() => setShowExportModal(true)}
            disabled={!mixedImage}
            data-testid="export-button"
          >
            <i className="fas fa-download w-4 h-4"></i>
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 h-full">
          {/* Upload Area for Multiple Images */}
          <div className="xl:col-span-2 space-y-6">
            <div className="bg-card rounded-lg border border-border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Upload Images to Mix</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[0, 1, 2].map((index) => (
                  <div key={index} className="relative">
                    {uploadedImages[index] ? (
                      <div className="relative rounded-lg border border-border overflow-hidden aspect-square">
                        <img 
                          src={uploadedImages[index]} 
                          alt={`Uploaded image ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                        <button
                          className="absolute top-2 right-2 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center text-xs hover:bg-destructive/90"
                          onClick={() => removeImage(index)}
                          data-testid={`remove-image-${index}`}
                        >
                          <i className="fas fa-times"></i>
                        </button>
                        <div className="absolute bottom-2 left-2 text-xs bg-background/80 px-2 py-1 rounded">
                          {index === 0 ? "Base Layer" : `Overlay ${index}`}
                        </div>
                      </div>
                    ) : (
                      <FileUpload
                        onFileUpload={handleFileUpload}
                        isUploading={createProjectMutation.isPending}
                        accept="image/*"
                        maxSize={10 * 1024 * 1024}
                        className="aspect-square"
                        label={index === 0 ? "Base Layer" : `Overlay ${index}`}
                        compact
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <ImagePreview
              originalImage={uploadedImages[0]}
              processedImage={mixedImage}
              isProcessing={isProcessing}
              progress={processingProgress}
              label="Mixed Result"
            />
          </div>

          {/* Mixing Controls */}
          <div className="space-y-6">
            {/* Blending Options */}
            <div className="bg-card rounded-lg border border-border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Blending Mode</h3>
              <div className="space-y-3">
                {[
                  { value: "natural", label: "Natural Blend" },
                  { value: "artistic", label: "Artistic Mix" },
                  { value: "dramatic", label: "Dramatic Effect" },
                ].map(({ value, label }) => (
                  <div key={value} className="flex items-center space-x-3">
                    <input
                      type="radio"
                      name="blend-mode"
                      id={value}
                      className="w-4 h-4 text-primary"
                      checked={mixingOptions.blendMode === value}
                      onChange={() => setMixingOptions(prev => ({ ...prev, blendMode: value as any }))}
                      data-testid={`blend-mode-${value}`}
                    />
                    <label htmlFor={value} className="text-sm font-medium text-foreground">
                      {label}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Layer Controls */}
            <div className="bg-card rounded-lg border border-border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Layer Controls</h3>
              <div className="space-y-4">
                {mixingOptions.layers.map((layer, index) => (
                  <div key={index} className="border border-border rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">
                        {index === 0 ? "Base Layer" : `Overlay ${index}`}
                      </span>
                      <button className="text-muted-foreground hover:text-foreground">
                        <i className="fas fa-eye text-xs"></i>
                      </button>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-3">
                        <span className="text-xs text-muted-foreground w-12">Opacity</span>
                        <input
                          type="range"
                          className="flex-1 h-1.5 bg-muted rounded-lg appearance-none cursor-pointer"
                          min="0"
                          max="100"
                          value={layer.opacity}
                          onChange={(e) => updateLayerOption(index, "opacity", parseInt(e.target.value))}
                          data-testid={`layer-${index}-opacity`}
                        />
                        <span className="text-xs text-muted-foreground w-8">{layer.opacity}%</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-xs text-muted-foreground w-12">Scale</span>
                        <input
                          type="range"
                          className="flex-1 h-1.5 bg-muted rounded-lg appearance-none cursor-pointer"
                          min="50"
                          max="150"
                          value={layer.scale}
                          onChange={(e) => updateLayerOption(index, "scale", parseInt(e.target.value))}
                          data-testid={`layer-${index}-scale`}
                        />
                        <span className="text-xs text-muted-foreground w-8">{layer.scale}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Mix Button */}
            <div className="bg-card rounded-lg border border-border p-6">
              <button
                className="w-full px-4 py-2 bg-primary text-primary-foreground font-medium rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
                onClick={handleMixImages}
                disabled={uploadedImages.length < 2 || isProcessing}
                data-testid="mix-images-button"
              >
                <i className="fas fa-layer-group mr-2"></i>
                {isProcessing ? "Mixing..." : "Mix Images"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        imageUrl={mixedImage}
        defaultFilename="mixed-image"
      />
    </>
  );
}
