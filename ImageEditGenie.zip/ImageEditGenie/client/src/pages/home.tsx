import { useState } from "react";
import Sidebar from "@/components/sidebar";
import BackgroundRemoval from "@/components/background-removal";
import ImageMixing from "@/components/image-mixing";

export default function Home() {
  const [activeTab, setActiveTab] = useState<"background-removal" | "image-mixing">("background-removal");

  return (
    <div className="flex h-screen" data-testid="main-layout">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      <div className="flex-1 flex flex-col">
        {activeTab === "background-removal" && <BackgroundRemoval />}
        {activeTab === "image-mixing" && <ImageMixing />}
      </div>
    </div>
  );
}
