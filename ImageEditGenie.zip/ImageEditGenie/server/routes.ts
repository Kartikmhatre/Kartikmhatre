import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { imageProcessor } from "./services/image-processor";
import { insertProjectSchema, insertJobSchema } from "@shared/schema";
import multer from "multer";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get user projects
  app.get("/api/projects", async (req, res) => {
    try {
      // For demo purposes, using a default user ID
      const userId = "demo-user";
      const projects = await storage.getUserProjects(userId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  // Create new project
  app.post("/api/projects", async (req, res) => {
    try {
      const data = insertProjectSchema.parse({
        ...req.body,
        userId: "demo-user" // Demo user ID
      });
      const project = await storage.createProject(data);
      res.json(project);
    } catch (error) {
      res.status(400).json({ error: "Invalid project data" });
    }
  });

  // Upload image for processing
  app.post("/api/projects/:id/upload", upload.single('image'), async (req, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      if (!req.file) {
        return res.status(400).json({ error: "No image file provided" });
      }

      // Convert buffer to base64
      const imageBase64 = req.file.buffer.toString('base64');
      
      // Update project with original image
      await storage.updateProject(id, {
        originalImageUrl: `data:${req.file.mimetype};base64,${imageBase64}`
      });

      res.json({ 
        message: "Image uploaded successfully",
        imageUrl: `data:${req.file.mimetype};base64,${imageBase64}`
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to upload image" });
    }
  });

  // Process background removal
  app.post("/api/projects/:id/remove-background", async (req, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getProject(id);
      
      if (!project || !project.originalImageUrl) {
        return res.status(404).json({ error: "Project or image not found" });
      }

      // Create processing job
      const job = await storage.createJob({
        projectId: id,
        status: "pending",
        progress: 0,
        errorMessage: null
      });

      // Start background removal process
      const options = {
        quality: req.body.quality || "standard",
        edgeRefinement: req.body.edgeRefinement || 75,
        feathering: req.body.feathering || 25,
        brightness: req.body.brightness || 0,
        contrast: req.body.contrast || 0,
        saturation: req.body.saturation || 0
      };

      // Extract base64 from data URL
      const imageBase64 = project.originalImageUrl.split(',')[1];

      // Process in background
      imageProcessor.removeBackground(imageBase64, options, job.id)
        .then(async (processedImage) => {
          const processedImageUrl = `data:image/png;base64,${processedImage}`;
          await storage.updateProject(id, { processedImageUrl });
        })
        .catch(console.error);

      res.json({ jobId: job.id });
    } catch (error) {
      res.status(500).json({ error: "Failed to start background removal" });
    }
  });

  // Process image mixing
  app.post("/api/projects/:id/mix-images", async (req, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const { images, options } = req.body;

      if (!images || images.length < 2) {
        return res.status(400).json({ error: "At least 2 images required for mixing" });
      }

      // Create processing job
      const job = await storage.createJob({
        projectId: id,
        status: "pending",
        progress: 0,
        errorMessage: null
      });

      // Process in background
      imageProcessor.mixImages(images, options, job.id)
        .then(async (mixedImage) => {
          const processedImageUrl = `data:image/png;base64,${mixedImage}`;
          await storage.updateProject(id, { processedImageUrl });
        })
        .catch(console.error);

      res.json({ jobId: job.id });
    } catch (error) {
      res.status(500).json({ error: "Failed to start image mixing" });
    }
  });

  // Get job status
  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const job = await storage.getJob(id);
      
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      res.json(job);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch job status" });
    }
  });

  // Get processed project
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
