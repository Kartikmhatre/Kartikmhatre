interface ImagePreviewProps {
  originalImage?: string | null;
  processedImage?: string | null;
  isProcessing?: boolean;
  progress?: number;
  label?: string;
}

export default function ImagePreview({
  originalImage,
  processedImage,
  isProcessing = false,
  progress = 0,
  label = "Preview",
}: ImagePreviewProps) {
  return (
    <div className="bg-card rounded-lg border border-border p-6 flex-1" data-testid="image-preview">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">{label}</h3>
        <div className="flex items-center space-x-2">
          <button 
            className="px-3 py-1 text-xs font-medium bg-secondary text-secondary-foreground rounded-md"
            data-testid="preview-original"
          >
            Original
          </button>
          <button 
            className="px-3 py-1 text-xs font-medium bg-primary text-primary-foreground rounded-md"
            data-testid="preview-processed"
          >
            Processed
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Original Image */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-muted-foreground">Original</label>
          <div className="image-preview aspect-square rounded-lg border border-border bg-muted flex items-center justify-center">
            {originalImage ? (
              <img 
                src={originalImage} 
                alt="Original image" 
                className="w-full h-full object-cover rounded-lg"
                data-testid="original-image"
              />
            ) : (
              <div className="text-center text-muted-foreground">
                <i className="fas fa-image text-2xl mb-2"></i>
                <p className="text-sm">No image uploaded</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Processed Image */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-muted-foreground">
            {label.includes("Mixed") ? "Mixed Result" : "Background Removed"}
          </label>
          <div className="image-preview aspect-square rounded-lg border border-border flex items-center justify-center relative">
            {processedImage ? (
              <img 
                src={processedImage} 
                alt="Processed image" 
                className="w-full h-full object-cover rounded-lg"
                data-testid="processed-image"
              />
            ) : isProcessing ? (
              <div className="absolute inset-0 bg-background/80 rounded-lg flex items-center justify-center processing-animation">
                <div className="text-center space-y-3">
                  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                  <div className="text-sm font-medium text-foreground">Processing...</div>
                  <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary transition-all duration-300 rounded-full"
                      style={{ width: `${progress}%` }}
                      data-testid="progress-bar"
                    ></div>
                  </div>
                  <div className="text-xs text-muted-foreground">{progress}%</div>
                </div>
              </div>
            ) : (
              <div className="text-center text-muted-foreground">
                <i className="fas fa-magic text-2xl mb-2"></i>
                <p className="text-sm">Processed image will appear here</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
