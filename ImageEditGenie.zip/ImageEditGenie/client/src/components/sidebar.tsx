import { useQuery } from "@tanstack/react-query";
import { Project } from "@shared/schema";

interface SidebarProps {
  activeTab: "background-removal" | "image-mixing";
  onTabChange: (tab: "background-removal" | "image-mixing") => void;
}

export default function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-magic text-primary-foreground text-sm"></i>
          </div>
          <h1 className="text-xl font-bold text-foreground">ImageCraft AI</h1>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2 flex-1">
        <div className="mb-6">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Tools</h3>
          <div className="space-y-1">
            <button
              className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === "background-removal"
                  ? "bg-accent text-accent-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
              onClick={() => onTabChange("background-removal")}
              data-testid="tab-background-removal"
            >
              <i className="fas fa-cut w-4 h-4"></i>
              <span>Background Removal</span>
            </button>
            <button
              className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === "image-mixing"
                  ? "bg-accent text-accent-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
              onClick={() => onTabChange("image-mixing")}
              data-testid="tab-image-mixing"
            >
              <i className="fas fa-layer-group w-4 h-4"></i>
              <span>Image Mixing</span>
            </button>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Recent Projects</h3>
          <div className="space-y-2">
            {projects.length === 0 ? (
              <p className="text-sm text-muted-foreground px-3 py-2">No recent projects</p>
            ) : (
              projects.slice(0, 5).map((project) => (
                <div
                  key={project.id}
                  className="flex items-center space-x-3 px-3 py-2 text-sm text-muted-foreground hover:bg-accent rounded-md cursor-pointer transition-colors"
                  data-testid={`project-${project.id}`}
                >
                  <i className="fas fa-file-image w-4 h-4"></i>
                  <span className="truncate">{project.name}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3" data-testid="user-profile">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
            <i className="fas fa-user text-muted-foreground text-sm"></i>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground">Demo User</p>
            <p className="text-xs text-muted-foreground">Pro Plan</p>
          </div>
          <button className="text-muted-foreground hover:text-foreground" data-testid="settings-button">
            <i className="fas fa-cog w-4 h-4"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
