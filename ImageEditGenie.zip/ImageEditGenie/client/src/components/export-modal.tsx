import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string | null;
  defaultFilename: string;
}

export default function ExportModal({
  isOpen,
  onClose,
  imageUrl,
  defaultFilename,
}: ExportModalProps) {
  const [filename, setFilename] = useState(defaultFilename);
  const [format, setFormat] = useState("png");
  const [quality, setQuality] = useState("4k");

  const handleDownload = () => {
    if (!imageUrl) return;

    const link = document.createElement("a");
    link.href = imageUrl;
    link.download = `${filename}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onClose();
  };

  const getEstimatedFileSize = () => {
    switch (quality) {
      case "4k": return "2.4 MB";
      case "2k": return "1.2 MB";
      case "1080p": return "800 KB";
      default: return "2.4 MB";
    }
  };

  const getDimensions = () => {
    switch (quality) {
      case "4k": return "3840 × 2160";
      case "2k": return "2048 × 2048";
      case "1080p": return "1920 × 1080";
      default: return "3840 × 2160";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="export-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Export Image
            <button 
              className="text-muted-foreground hover:text-foreground"
              onClick={onClose}
              data-testid="close-modal"
            >
              <i className="fas fa-times"></i>
            </button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="filename" className="text-sm font-medium text-foreground mb-2 block">
              File Name
            </Label>
            <Input
              id="filename"
              type="text"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              className="w-full"
              data-testid="filename-input"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium text-foreground mb-2 block">
                Format
              </Label>
              <Select value={format} onValueChange={setFormat}>
                <SelectTrigger data-testid="format-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="png">PNG</SelectItem>
                  <SelectItem value="jpg">JPG</SelectItem>
                  <SelectItem value="webp">WebP</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium text-foreground mb-2 block">
                Quality
              </Label>
              <Select value={quality} onValueChange={setQuality}>
                <SelectTrigger data-testid="quality-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="4k">4K (Ultra)</SelectItem>
                  <SelectItem value="2k">2K (High)</SelectItem>
                  <SelectItem value="1080p">1080p (Standard)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Estimated file size:</span>
              <span className="font-medium text-foreground">{getEstimatedFileSize()}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-1">
              <span className="text-muted-foreground">Dimensions:</span>
              <span className="font-medium text-foreground">{getDimensions()}</span>
            </div>
          </div>
        </div>

        <div className="flex space-x-3 mt-6">
          <Button 
            variant="secondary" 
            className="flex-1"
            onClick={onClose}
            data-testid="cancel-download"
          >
            Cancel
          </Button>
          <Button 
            className="flex-1"
            onClick={handleDownload}
            disabled={!imageUrl || !filename}
            data-testid="confirm-download"
          >
            <i className="fas fa-download mr-2"></i>
            Download
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
